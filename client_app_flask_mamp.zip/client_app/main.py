import math
import re

from flask import Flask, render_template, request, redirect, url_for, flash

from db import (
    COMPANIES,
    PAGE_SIZE,
    add_client,
    count_clients,
    delete_client,
    get_client_by_id,
    get_clients,
    init_db,
    update_client
)

app = Flask(__name__)
app.secret_key = "clients_secret_key"

EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
PHONE_RE = re.compile(r"^[0-9+\-()]+$")


def get_form_data():
    return {
        "full_name": request.form.get("full_name", "").strip(),
        "phone": request.form.get("phone", "").strip(),
        "email": request.form.get("email", "").strip(),
        "company": request.form.get("company", "").strip(),
        "notes": request.form.get("notes", "").strip()
    }


def validate_client(data):
    errors = []

    if not all(data.values()):
        errors.append("Все поля обязательны для заполнения")

    if data["email"] and not EMAIL_RE.fullmatch(data["email"]):
        errors.append("Некорректный e-mail")

    if data["phone"]:
        if not PHONE_RE.fullmatch(data["phone"]):
            errors.append("Телефон может содержать только цифры и символы + - ( )")

        if not any(char.isdigit() for char in data["phone"]):
            errors.append("Телефон должен содержать хотя бы одну цифру")

    if data["company"] and data["company"] not in COMPANIES:
        errors.append("Компания должна быть выбрана из списка")

    return errors


def get_positive_int(value, default=1):
    try:
        number = int(value)

        if number < 1:
            return default

        return number

    except (TypeError, ValueError):
        return default


def get_list_context(form_data=None, edit_client=None):
    search = request.args.get("search", "").strip()
    selected_company = request.args.get("company", "").strip()

    if selected_company not in COMPANIES:
        selected_company = ""

    page = get_positive_int(request.args.get("page"), 1)

    total_clients = count_clients(search, selected_company)
    total_pages = max(math.ceil(total_clients / PAGE_SIZE), 1)

    if page > total_pages:
        page = total_pages

    clients = get_clients(search, selected_company, page, PAGE_SIZE)

    return {
        "clients": clients,
        "companies": COMPANIES,
        "form_data": form_data or {},
        "edit_client": edit_client,
        "search": search,
        "selected_company": selected_company,
        "page": page,
        "total_pages": total_pages,
        "total_clients": total_clients
    }


@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        data = get_form_data()
        errors = validate_client(data)

        if errors:
            for error in errors:
                flash(error, "red")

            return render_template("index.html", **get_list_context(form_data=data))

        add_client(data)
        flash("Клиент успешно добавлен", "green")

        return redirect(url_for("index"))

    return render_template("index.html", **get_list_context())


@app.route("/edit/<int:client_id>", methods=["GET", "POST"])
def edit_client_route(client_id):
    client = get_client_by_id(client_id)

    if not client:
        flash("Клиент не найден", "red")
        return redirect(url_for("index"))

    if request.method == "POST":
        data = get_form_data()
        errors = validate_client(data)

        if errors:
            for error in errors:
                flash(error, "red")

            data["id"] = client_id
            return render_template("index.html", **get_list_context(edit_client=data))

        update_client(client_id, data)
        flash("Клиент успешно изменён", "green")

        return redirect(url_for("index"))

    return render_template("index.html", **get_list_context(edit_client=client))


@app.route("/delete/<int:client_id>", methods=["POST"])
def delete_client_route(client_id):
    confirmed = request.form.get("confirmed")

    if confirmed == "yes":
        delete_client(client_id)
        flash("Клиент удалён", "green")
    else:
        flash("Удаление не подтверждено", "red")

    return redirect(url_for("index"))


if __name__ == "__main__":
    init_db()
    app.run(debug=True)
