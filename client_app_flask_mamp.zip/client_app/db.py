import pymysql

# Настройки MAMP/MySQL.
# Если у тебя в MAMP другой порт, замени port на 3306 или 8889.
DB_CONFIG = {
    "host": "localhost",
    "port": 3306,
    "user": "pk211",
    "password": "1234",
    "database": "pk211",
    "charset": "utf8mb4",
    "cursorclass": pymysql.cursors.DictCursor
}

# Компания должна выбираться только из этого списка.
COMPANIES = [
    "Яндекс",
    "VK",
    "Сбер",
    "Газпром",
    "МТС",
    "Ростелеком"
]

# Размер страницы для серверной пагинации.
PAGE_SIZE = 5


def get_db_connection():
    return pymysql.connect(**DB_CONFIG)


def init_db():
    """Создание таблицы, если она ещё не создана."""
    connection = get_db_connection()

    try:
        with connection.cursor() as cursor:
            cursor.execute(
                """
                CREATE TABLE IF NOT EXISTS clients (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    full_name VARCHAR(150) NOT NULL,
                    phone VARCHAR(30) NOT NULL,
                    email VARCHAR(120) NOT NULL,
                    company VARCHAR(60) NOT NULL,
                    notes TEXT NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
                """
            )

        connection.commit()

    finally:
        connection.close()


def add_client(data):
    connection = get_db_connection()

    try:
        with connection.cursor() as cursor:
            cursor.execute(
                """
                INSERT INTO clients
                (full_name, phone, email, company, notes)
                VALUES (%s, %s, %s, %s, %s)
                """,
                (
                    data["full_name"],
                    data["phone"],
                    data["email"],
                    data["company"],
                    data["notes"]
                )
            )

        connection.commit()

    finally:
        connection.close()


def get_client_by_id(client_id):
    connection = get_db_connection()

    try:
        with connection.cursor() as cursor:
            cursor.execute(
                "SELECT * FROM clients WHERE id = %s",
                (client_id,)
            )

            return cursor.fetchone()

    finally:
        connection.close()


def update_client(client_id, data):
    connection = get_db_connection()

    try:
        with connection.cursor() as cursor:
            cursor.execute(
                """
                UPDATE clients
                SET full_name = %s,
                    phone = %s,
                    email = %s,
                    company = %s,
                    notes = %s
                WHERE id = %s
                """,
                (
                    data["full_name"],
                    data["phone"],
                    data["email"],
                    data["company"],
                    data["notes"],
                    client_id
                )
            )

        connection.commit()

    finally:
        connection.close()


def delete_client(client_id):
    connection = get_db_connection()

    try:
        with connection.cursor() as cursor:
            cursor.execute(
                "DELETE FROM clients WHERE id = %s",
                (client_id,)
            )

        connection.commit()

    finally:
        connection.close()


def _make_filter(search, company):
    conditions = []
    params = []

    if search:
        conditions.append("full_name LIKE %s")
        params.append(f"%{search}%")

    if company:
        conditions.append("company = %s")
        params.append(company)

    if conditions:
        return " WHERE " + " AND ".join(conditions), params

    return "", params


def count_clients(search="", company=""):
    connection = get_db_connection()

    try:
        where_sql, params = _make_filter(search, company)

        with connection.cursor() as cursor:
            cursor.execute(
                f"SELECT COUNT(*) AS total FROM clients{where_sql}",
                params
            )

            result = cursor.fetchone()
            return result["total"]

    finally:
        connection.close()


def get_clients(search="", company="", page=1, page_size=PAGE_SIZE):
    offset = (page - 1) * page_size

    connection = get_db_connection()

    try:
        where_sql, params = _make_filter(search, company)

        sql = f"""
            SELECT *
            FROM clients
            {where_sql}
            ORDER BY id DESC
            LIMIT %s OFFSET %s
        """

        params.extend([page_size, offset])

        with connection.cursor() as cursor:
            cursor.execute(sql, params)
            return cursor.fetchall()

    finally:
        connection.close()
