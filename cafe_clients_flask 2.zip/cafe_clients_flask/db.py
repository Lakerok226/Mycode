import pymysql


DB_CONFIG = {
    "host": "localhost",
    "port": 8889,          # Для MAMP часто используется 8889. Если у тебя 3306, замени на 3306.
    "user": "pk211",      # Если MAMP стандартный: user="root"
    "password": "1234",   # Если MAMP стандартный: password="root"
    "database": "pk211",
    "charset": "utf8mb4",
    "cursorclass": pymysql.cursors.DictCursor
}


def get_db_connection():
    return pymysql.connect(**DB_CONFIG)


def create_clients_table():
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS clients (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(100) NOT NULL,
            phone VARCHAR(30) NOT NULL UNIQUE,
            email VARCHAR(100) NOT NULL UNIQUE,
            bonus_balance DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
            registration_date DATE NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            CONSTRAINT chk_bonus_balance CHECK (bonus_balance >= 0)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        """
    )

    conn.commit()
    cursor.close()
    conn.close()


def phone_or_email_exists(phone, email, exclude_id=None):
    conn = get_db_connection()
    cursor = conn.cursor()

    if exclude_id is None:
        cursor.execute(
            "SELECT id FROM clients WHERE phone = %s OR email = %s LIMIT 1",
            (phone, email)
        )
    else:
        cursor.execute(
            """
            SELECT id FROM clients
            WHERE (phone = %s OR email = %s) AND id != %s
            LIMIT 1
            """,
            (phone, email, exclude_id)
        )

    result = cursor.fetchone()
    cursor.close()
    conn.close()

    return result is not None


def add_client(client):
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute(
        """
        INSERT INTO clients
        (name, phone, email, bonus_balance, registration_date)
        VALUES (%s, %s, %s, %s, %s)
        """,
        (
            client["name"],
            client["phone"],
            client["email"],
            client["bonus_balance"],
            client["registration_date"]
        )
    )

    conn.commit()
    cursor.close()
    conn.close()


def update_client(client_id, client):
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute(
        """
        UPDATE clients
        SET name = %s,
            phone = %s,
            email = %s,
            bonus_balance = %s,
            registration_date = %s
        WHERE id = %s
        """,
        (
            client["name"],
            client["phone"],
            client["email"],
            client["bonus_balance"],
            client["registration_date"],
            client_id
        )
    )

    conn.commit()
    cursor.close()
    conn.close()


def delete_client(client_id):
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("DELETE FROM clients WHERE id = %s", (client_id,))

    conn.commit()
    cursor.close()
    conn.close()


def get_client_by_id(client_id):
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM clients WHERE id = %s", (client_id,))
    client = cursor.fetchone()

    cursor.close()
    conn.close()

    return client


def get_clients(search="", min_balance=None, max_balance=None, page=1, per_page=5):
    where_parts = []
    params = []

    if search:
        where_parts.append("(name LIKE %s OR phone LIKE %s)")
        params.extend([f"%{search}%", f"%{search}%"])

    if min_balance is not None:
        where_parts.append("bonus_balance >= %s")
        params.append(min_balance)

    if max_balance is not None:
        where_parts.append("bonus_balance <= %s")
        params.append(max_balance)

    where_sql = ""
    if where_parts:
        where_sql = "WHERE " + " AND ".join(where_parts)

    offset = (page - 1) * per_page

    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute(f"SELECT COUNT(*) AS total FROM clients {where_sql}", params)
    total = cursor.fetchone()["total"]

    cursor.execute(
        f"""
        SELECT * FROM clients
        {where_sql}
        ORDER BY registration_date DESC, id DESC
        LIMIT %s OFFSET %s
        """,
        params + [per_page, offset]
    )
    clients = cursor.fetchall()

    cursor.close()
    conn.close()

    return clients, total
