Проект: Flask-приложение «Клиенты кафе»

Структура:
- main.py
- db.py
- clients.sql
- templates/add_client.html

Запуск:
1. Запусти MySQL в MAMP.
2. В phpMyAdmin выполни файл clients.sql.
3. Проверь настройки подключения в db.py.
   Для MAMP часто: host=localhost, port=8889, user=root, password=root.
   Если у тебя уже есть пользователь pk211/1234 и база pk211, оставь как есть.
4. Установи библиотеки:
   pip install flask pymysql
5. Запусти:
   python main.py
6. Открой в браузере:
   http://127.0.0.1:5000
