import math
import re
from datetime import date
from decimal import Decimal, InvalidOperation

import pymysql
from flask import Flask, render_template, request, redirect, url_for, flash

from db import (
    create_clients_table,
    phone_or_email_exists,
    add_client,
    update_client,
    delete_client,
    get_client_by_id,
    get_clients
)


app = Flask(__name__)
app.secret_key = "secret_key"

PER_PAGE = 5


EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
PHONE_ALLOWED_RE = re.compile(r"^[+\d\s()\-]+$")


def validate_client_form(form, client_id=None):
    errors = []

    name = form.get("name", "").strip()
    phone = form.get("phone", "").strip()
    email = form.get("email", "").strip().lower()
    bonus_balance = form.get("bonus_balance", "").strip()
    registration_date = form.get("registration_date", "").strip()

    if not all([name, phone, email, bonus_balance, registration_date]):
        errors.append("Все поля обязательны")

    if phone and not PHONE_ALLOWED_RE.match(phone):
        errors.append("Телефон может содержать только цифры, пробелы, +, -, скобки")

    digits_count = len(re.sub(r"\D", "", phone))
    if phone and (digits_count < 7 or digits_count > 15):
        errors.append("Телефон должен содержать от 7 до 15 цифр")

    if email and not EMAIL_RE.match(email):
        errors.append("Некорректный e-mail")

    try:
        bonus_balance_decimal = Decimal(bonus_balance)
        if bonus_balance_decimal < 0:
            errors.append("Баланс бонусов не может быть отрицательным")
    except InvalidOperation:
        bonus_balance_decimal = None
        errors.append("Баланс бонусов должен быть числом")

    try:
        registration_date_value = date.fromisoformat(registration_date)
    except ValueError:
        registration_date_value = None
        errors.append("Дата регистрации должна быть корректной")

    if phone and email and phone_or_email_exists(phone, email, client_id):
        errors.append("Клиент с таким телефоном или e-mail уже существует")

    client = {
        "name": name,
        "phone": phone,
        "email": email,
        "bonus_balance": bonus_balance_decimal,
        "registration_date": registration_date_value
    }

    return errors, client


def parse_balance_filter(value):
    value = value.strip()
    if not value:
        return None

    try:
        balance = Decimal(value)
        if balance < 0:
            raise InvalidOperation
        return balance
    except InvalidOperation:
        return None


@app.route("/", methods=["GET"])
def index():
    search = request.args.get("search", "").strip()
    min_balance_raw = request.args.get("min_balance", "").strip()
    max_balance_raw = request.args.get("max_balance", "").strip()
    page = request.args.get("page", 1, type=int)

    if page < 1:
        page = 1

    min_balance = parse_balance_filter(min_balance_raw)
    max_balance = parse_balance_filter(max_balance_raw)

    if min_balance_raw and min_balance is None:
        flash("Минимальный баланс должен быть неотрицательным числом")

    if max_balance_raw and max_balance is None:
        flash("Максимальный баланс должен быть неотрицательным числом")

    clients, total = get_clients(
        search=search,
        min_balance=min_balance,
        max_balance=max_balance,
        page=page,
        per_page=PER_PAGE
    )

    total_pages = max(1, math.ceil(total / PER_PAGE))

    return render_template(
        "add_client.html",
        clients=clients,
        edit_client=None,
        page=page,
        total_pages=total_pages,
        total=total,
        search=search,
        min_balance=min_balance_raw,
        max_balance=max_balance_raw
    )


@app.route("/add", methods=["POST"])
def add_client_route():
    errors, client = validate_client_form(request.form)

    if errors:
        for error in errors:
            flash(error)
        return redirect(url_for("index"))

    try:
        add_client(client)
        flash("Клиент успешно добавлен")
    except pymysql.err.IntegrityError:
        flash("Клиент с таким телефоном или e-mail уже существует")

    return redirect(url_for("index"))


@app.route("/edit/<int:client_id>", methods=["GET", "POST"])
def edit_client_route(client_id):
    current_client = get_client_by_id(client_id)

    if current_client is None:
        flash("Клиент не найден")
        return redirect(url_for("index"))

    if request.method == "POST":
        errors, client = validate_client_form(request.form, client_id)

        if errors:
            for error in errors:
                flash(error)
            return redirect(url_for("edit_client_route", client_id=client_id))

        try:
            update_client(client_id, client)
            flash("Данные клиента успешно обновлены")
        except pymysql.err.IntegrityError:
            flash("Клиент с таким телефоном или e-mail уже существует")

        return redirect(url_for("index"))

    clients, total = get_clients(page=1, per_page=PER_PAGE)
    total_pages = max(1, math.ceil(total / PER_PAGE))

    return render_template(
        "add_client.html",
        clients=clients,
        edit_client=current_client,
        page=1,
        total_pages=total_pages,
        total=total,
        search="",
        min_balance="",
        max_balance=""
    )


@app.route("/delete/<int:client_id>", methods=["POST"])
def delete_client_route(client_id):
    delete_client(client_id)
    flash("Клиент удалён")
    return redirect(url_for("index"))


if __name__ == "__main__":
    create_clients_table()
    app.run(debug=True)
