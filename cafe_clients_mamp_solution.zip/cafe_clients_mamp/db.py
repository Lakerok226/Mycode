import math

import mysql.connector

# Настройки MAMP.
# В стандартном MAMP для macOS обычно:
# host = "127.0.0.1", port = 8889, user = "root", password = "root".
# Если у тебя в MAMP указан другой MySQL Port, измени значение port ниже.
DB_NAME = "cafe_db"

DB_CONFIG = {
    "host": "127.0.0.1",
    "port": 8889,
    "user": "root",
    "password": "root",
    "database": DB_NAME,
    "charset": "utf8mb4",
}


def get_server_connection():
    """Подключение к MySQL-серверу MAMP без выбора базы данных."""
    config = DB_CONFIG.copy()
    config.pop("database")
    return mysql.connector.connect(**config)


def get_connection():
    """Подключение к базе данных приложения."""
    return mysql.connector.connect(**DB_CONFIG)


def init_db():
    """Создает базу cafe_db и таблицу clients, если их еще нет."""
    with get_server_connection() as conn:
        with conn.cursor() as cursor:
            cursor.execute(
                f"CREATE DATABASE IF NOT EXISTS {DB_NAME} "
                "DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci"
            )
        conn.commit()

    with get_connection() as conn:
        with conn.cursor() as cursor:
            cursor.execute(
                """
                CREATE TABLE IF NOT EXISTS clients (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    name VARCHAR(100) NOT NULL,
                    phone VARCHAR(30) NOT NULL UNIQUE,
                    email VARCHAR(120) NOT NULL UNIQUE,
                    bonus_balance DECIMAL(10, 2) NOT NULL DEFAULT 0,
                    registration_date DATE NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
                """
            )
        conn.commit()


def add_client(client):
    sql = """
        INSERT INTO clients (name, phone, email, bonus_balance, registration_date)
        VALUES (%s, %s, %s, %s, %s)
    """
    params = (
        client["name"],
        client["phone"],
        client["email"],
        client["bonus_balance"],
        client["registration_date"],
    )

    with get_connection() as conn:
        with conn.cursor() as cursor:
            cursor.execute(sql, params)
        conn.commit()


def update_client(client_id, client):
    sql = """
        UPDATE clients
        SET name = %s, phone = %s, email = %s, bonus_balance = %s, registration_date = %s
        WHERE id = %s
    """
    params = (
        client["name"],
        client["phone"],
        client["email"],
        client["bonus_balance"],
        client["registration_date"],
        client_id,
    )

    with get_connection() as conn:
        with conn.cursor() as cursor:
            cursor.execute(sql, params)
        conn.commit()


def delete_client(client_id):
    with get_connection() as conn:
        with conn.cursor() as cursor:
            cursor.execute("DELETE FROM clients WHERE id = %s", (client_id,))
        conn.commit()


def get_client(client_id):
    with get_connection() as conn:
        with conn.cursor(dictionary=True) as cursor:
            cursor.execute("SELECT * FROM clients WHERE id = %s", (client_id,))
            return cursor.fetchone()


def find_client_by_phone_or_email(phone, email, exclude_id=None):
    sql = "SELECT * FROM clients WHERE (phone = %s OR email = %s)"
    params = [phone, email]

    if exclude_id is not None:
        sql += " AND id <> %s"
        params.append(exclude_id)

    sql += " LIMIT 1"

    with get_connection() as conn:
        with conn.cursor(dictionary=True) as cursor:
            cursor.execute(sql, tuple(params))
            return cursor.fetchone()


def get_clients(q="", min_balance=None, max_balance=None, page=1, per_page=5):
    where = []
    params = []

    if q:
        where.append("(name LIKE %s OR phone LIKE %s)")
        like = f"%{q}%"
        params.extend([like, like])

    if min_balance is not None:
        where.append("bonus_balance >= %s")
        params.append(min_balance)

    if max_balance is not None:
        where.append("bonus_balance <= %s")
        params.append(max_balance)

    where_sql = " WHERE " + " AND ".join(where) if where else ""

    page = max(page, 1)
    offset = (page - 1) * per_page

    with get_connection() as conn:
        with conn.cursor(dictionary=True) as cursor:
            cursor.execute(f"SELECT COUNT(*) AS cnt FROM clients{where_sql}", tuple(params))
            total = cursor.fetchone()["cnt"]

            cursor.execute(
                f"""
                SELECT id, name, phone, email, bonus_balance, registration_date
                FROM clients
                {where_sql}
                ORDER BY id DESC
                LIMIT %s OFFSET %s
                """,
                tuple(params + [per_page, offset]),
            )
            clients = cursor.fetchall()

    pages = max(math.ceil(total / per_page), 1)
    return clients, total, pages
