from datetime import datetime
from decimal import Decimal, InvalidOperation
import re

from flask import Flask, render_template, request, redirect, url_for, flash

import db

app = Flask(__name__, template_folder=".")
app.secret_key = "change-this-secret-key"

PER_PAGE = 5


EMAIL_RE = re.compile(r"^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$")
PHONE_RE = re.compile(r"^\+?[0-9\s().-]{7,20}$")


def validate_client(form_data, client_id=None):
    """Общая валидация для добавления и редактирования клиента."""
    errors = {}

    name = (form_data.get("name") or "").strip()
    phone = (form_data.get("phone") or "").strip()
    email = (form_data.get("email") or "").strip().lower()
    balance_raw = (form_data.get("bonus_balance") or "").strip().replace(",", ".")
    registration_date_raw = (form_data.get("registration_date") or "").strip()

    if not name:
        errors["name"] = "Введите имя."

    if not phone:
        errors["phone"] = "Введите телефон."
    elif not PHONE_RE.fullmatch(phone) or not (7 <= len(re.sub(r"\D", "", phone)) <= 15):
        errors["phone"] = "Введите корректный телефон."

    if not email:
        errors["email"] = "Введите e-mail."
    elif not EMAIL_RE.fullmatch(email):
        errors["email"] = "Введите корректный e-mail."

    balance = None
    if not balance_raw:
        errors["bonus_balance"] = "Введите баланс бонусов."
    else:
        try:
            balance = Decimal(balance_raw)
            if balance < 0:
                errors["bonus_balance"] = "Баланс не может быть отрицательным."
        except InvalidOperation:
            errors["bonus_balance"] = "Баланс должен быть числом."

    registration_date = None
    if not registration_date_raw:
        errors["registration_date"] = "Введите дату регистрации."
    else:
        try:
            registration_date = datetime.strptime(registration_date_raw, "%Y-%m-%d").date()
        except ValueError:
            errors["registration_date"] = "Введите корректную дату."

    if "phone" not in errors and "email" not in errors:
        existing = db.find_client_by_phone_or_email(phone, email, exclude_id=client_id)
        if existing:
            if existing["phone"] == phone:
                errors["phone"] = "Клиент с таким телефоном уже существует."
            if existing["email"] == email:
                errors["email"] = "Клиент с таким e-mail уже существует."

    cleaned = {
        "name": name,
        "phone": phone,
        "email": email,
        "bonus_balance": balance,
        "registration_date": registration_date,
    }
    return len(errors) == 0, cleaned, errors


def get_filters():
    return {
        "q": (request.args.get("q") or "").strip(),
        "min_balance": (request.args.get("min_balance") or "").strip(),
        "max_balance": (request.args.get("max_balance") or "").strip(),
    }


def render_page(form=None, errors=None, edit_client=None):
    filters = get_filters()

    try:
        page = int(request.args.get("page", 1))
    except ValueError:
        page = 1

    try:
        min_balance = Decimal(filters["min_balance"].replace(",", ".")) if filters["min_balance"] else None
    except InvalidOperation:
        min_balance = None
        flash("Минимальный баланс должен быть числом.", "error")

    try:
        max_balance = Decimal(filters["max_balance"].replace(",", ".")) if filters["max_balance"] else None
    except InvalidOperation:
        max_balance = None
        flash("Максимальный баланс должен быть числом.", "error")

    clients, total, pages = db.get_clients(
        q=filters["q"],
        min_balance=min_balance,
        max_balance=max_balance,
        page=page,
        per_page=PER_PAGE,
    )

    if form is None:
        form = edit_client or {}

    return render_template(
        "index.html",
        clients=clients,
        total=total,
        page=page,
        pages=pages,
        filters=filters,
        form=form,
        errors=errors or {},
        edit_client=edit_client,
    )


@app.route("/", methods=["GET"])
def index():
    edit_id = request.args.get("edit_id")
    edit_client = db.get_client(int(edit_id)) if edit_id and edit_id.isdigit() else None
    return render_page(edit_client=edit_client)


@app.route("/add", methods=["POST"])
def add_client():
    is_valid, cleaned, errors = validate_client(request.form)
    if not is_valid:
        return render_page(form=request.form, errors=errors)

    db.add_client(cleaned)
    flash("Клиент добавлен.", "success")
    return redirect(url_for("index"))


@app.route("/update/<int:client_id>", methods=["POST"])
def update_client(client_id):
    edit_client = db.get_client(client_id)
    if not edit_client:
        flash("Клиент не найден.", "error")
        return redirect(url_for("index"))

    is_valid, cleaned, errors = validate_client(request.form, client_id=client_id)
    if not is_valid:
        return render_page(form=request.form, errors=errors, edit_client=edit_client)

    db.update_client(client_id, cleaned)
    flash("Клиент обновлен.", "success")
    return redirect(url_for("index"))


@app.route("/delete/<int:client_id>", methods=["POST"])
def delete_client(client_id):
    db.delete_client(client_id)
    flash("Клиент удален.", "success")
    return redirect(url_for("index"))


if __name__ == "__main__":
    db.init_db()
    app.run(debug=True)
