import re
from config import COMPANIES

EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
PHONE_RE = re.compile(r"^[0-9+\-() ]+$")


def validate_client(data):
    """Общая серверная валидация для добавления и редактирования клиента."""
    errors = {}

    full_name = data.get("full_name", "").strip()
    phone = data.get("phone", "").strip()
    email = data.get("email", "").strip()
    company = data.get("company", "").strip()
    notes = data.get("notes", "").strip()

    if not full_name:
        errors["full_name"] = "Введите ФИО."

    if not phone:
        errors["phone"] = "Введите телефон."
    elif not PHONE_RE.fullmatch(phone):
        errors["phone"] = "Телефон может содержать только цифры и символы + - ( ) пробел."

    if not email:
        errors["email"] = "Введите e-mail."
    elif not EMAIL_RE.fullmatch(email):
        errors["email"] = "Введите корректный e-mail."

    if not company:
        errors["company"] = "Выберите компанию."
    elif company not in COMPANIES:
        errors["company"] = "Выберите компанию из списка."

    if not notes:
        errors["notes"] = "Введите заметки."

    cleaned = {
        "full_name": full_name,
        "phone": phone,
        "email": email,
        "company": company,
        "notes": notes,
    }
    return errors, cleaned
