import re
from config import DB_CONFIG
from db import get_connection


def check_database_name(name):
    if not re.fullmatch(r"[A-Za-z0-9_]+", name):
        raise ValueError("Имя базы данных должно содержать только буквы, цифры и знак _")


def init_database():
    db_name = DB_CONFIG["database"]
    check_database_name(db_name)

    # Создаём базу, если её нет.
    conn = get_connection(database=False)
    cursor = conn.cursor()
    cursor.execute(
        f"CREATE DATABASE IF NOT EXISTS `{db_name}` "
        "CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci"
    )
    cursor.close()
    conn.close()

    # Создаём таблицу.
    conn = get_connection(database=True)
    cursor = conn.cursor()
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS clients (
            id INT AUTO_INCREMENT PRIMARY KEY,
            full_name VARCHAR(255) NOT NULL,
            phone VARCHAR(50) NOT NULL,
            email VARCHAR(255) NOT NULL,
            company VARCHAR(100) NOT NULL,
            notes TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        """
    )
    conn.commit()
    cursor.close()
    conn.close()
    print("База данных и таблица clients готовы.")


if __name__ == "__main__":
    init_database()
