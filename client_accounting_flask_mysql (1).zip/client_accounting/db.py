import mysql.connector
from mysql.connector import Error
from config import DB_CONFIG


def get_connection(database=True):
    """Возвращает подключение к MySQL. Модуль БД вынесен отдельно по заданию."""
    cfg = DB_CONFIG.copy()
    if not database:
        cfg.pop("database", None)
    try:
        return mysql.connector.connect(**cfg)
    except Error as exc:
        raise RuntimeError(f"Ошибка подключения к MySQL: {exc}") from exc
