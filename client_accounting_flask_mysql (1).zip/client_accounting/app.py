from math import ceil

from flask import Flask, flash, redirect, render_template, request, url_for

from config import COMPANIES, PER_PAGE, SECRET_KEY
from db import get_connection
from validators import validate_client

app = Flask(__name__)
app.config["SECRET_KEY"] = SECRET_KEY


def get_client_or_none(client_id):
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM clients WHERE id = %s", (client_id,))
    client = cursor.fetchone()
    cursor.close()
    conn.close()
    return client


@app.route("/")
def index():
    q = request.args.get("q", "").strip()
    company = request.args.get("company", "").strip()

    try:
        page = int(request.args.get("page", 1))
        if page < 1:
            page = 1
    except ValueError:
        page = 1

    where = []
    params = []

    if q:
        where.append("full_name LIKE %s")
        params.append(f"%{q}%")

    if company:
        # Фильтр по компании тоже проверяем по серверному списку.
        if company in COMPANIES:
            where.append("company = %s")
            params.append(company)
        else:
            flash("Недопустимое значение фильтра компании.", "red")
            company = ""

    where_sql = " WHERE " + " AND ".join(where) if where else ""

    conn = get_connection()
    cursor = conn.cursor(dictionary=True)

    cursor.execute(f"SELECT COUNT(*) AS total FROM clients{where_sql}", tuple(params))
    total = cursor.fetchone()["total"]
    total_pages = max(ceil(total / PER_PAGE), 1)
    if page > total_pages:
        page = total_pages

    offset = (page - 1) * PER_PAGE
    cursor.execute(
        f"""
        SELECT * FROM clients
        {where_sql}
        ORDER BY id DESC
        LIMIT %s OFFSET %s
        """,
        tuple(params + [PER_PAGE, offset]),
    )
    clients = cursor.fetchall()

    cursor.close()
    conn.close()

    return render_template(
        "index.html",
        clients=clients,
        companies=COMPANIES,
        q=q,
        company=company,
        page=page,
        total_pages=total_pages,
        total=total,
    )


@app.route("/clients/add", methods=["GET", "POST"])
def add_client():
    data = {"full_name": "", "phone": "", "email": "", "company": "", "notes": ""}
    errors = {}

    if request.method == "POST":
        errors, data = validate_client(request.form)
        if not errors:
            conn = get_connection()
            cursor = conn.cursor()
            cursor.execute(
                """
                INSERT INTO clients (full_name, phone, email, company, notes)
                VALUES (%s, %s, %s, %s, %s)
                """,
                (data["full_name"], data["phone"], data["email"], data["company"], data["notes"]),
            )
            conn.commit()
            cursor.close()
            conn.close()
            flash("Клиент добавлен.", "green")
            return redirect(url_for("index"))
        flash("Исправьте ошибки в форме. Запись не сохранена.", "red")

    return render_template(
        "form.html",
        title="Добавить клиента",
        action_url=url_for("add_client"),
        data=data,
        errors=errors,
        companies=COMPANIES,
    )


@app.route("/clients/<int:client_id>/edit", methods=["GET", "POST"])
def edit_client(client_id):
    client = get_client_or_none(client_id)
    if client is None:
        flash("Клиент не найден.", "red")
        return redirect(url_for("index"))

    data = dict(client)
    errors = {}

    if request.method == "POST":
        errors, data = validate_client(request.form)
        if not errors:
            conn = get_connection()
            cursor = conn.cursor()
            cursor.execute(
                """
                UPDATE clients
                SET full_name = %s, phone = %s, email = %s, company = %s, notes = %s
                WHERE id = %s
                """,
                (
                    data["full_name"],
                    data["phone"],
                    data["email"],
                    data["company"],
                    data["notes"],
                    client_id,
                ),
            )
            conn.commit()
            cursor.close()
            conn.close()
            flash("Клиент обновлён.", "green")
            return redirect(url_for("index"))
        flash("Исправьте ошибки в форме. Изменения не сохранены.", "red")

    return render_template(
        "form.html",
        title="Редактировать клиента",
        action_url=url_for("edit_client", client_id=client_id),
        data=data,
        errors=errors,
        companies=COMPANIES,
    )


@app.route("/clients/<int:client_id>/delete", methods=["GET", "POST"])
def delete_client(client_id):
    client = get_client_or_none(client_id)
    if client is None:
        flash("Клиент не найден.", "red")
        return redirect(url_for("index"))

    if request.method == "POST":
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("DELETE FROM clients WHERE id = %s", (client_id,))
        conn.commit()
        cursor.close()
        conn.close()
        flash("Клиент удалён.", "green")
        return redirect(url_for("index"))

    return render_template("confirm_delete.html", client=client)


if __name__ == "__main__":
    app.run(debug=True)
