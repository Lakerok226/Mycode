# Настройки приложения и MySQL.
# Измените DB_USER и DB_PASSWORD под свою локальную MySQL.

SECRET_KEY = "change-me-in-production"
PER_PAGE = 5

DB_CONFIG = {
    "host": "localhost",
    "port": 3306,
    "user": "root",
    "password": "",          # например: "12345"
    "database": "clients_app",
    "charset": "utf8mb4",
    "use_unicode": True,
}

# Компания должна выбираться только из этого списка.
COMPANIES = [
    "Google",
    "Microsoft",
    "Yandex",
    "Sber",
    "VK",
    "Ozon",
]
