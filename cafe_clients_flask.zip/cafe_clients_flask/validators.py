import re
from datetime import datetime
from decimal import Decimal, InvalidOperation

EMAIL_RE = re.compile(r"^[^\s@]+@[^\s@]+\.[^\s@]+$")
PHONE_RE = re.compile(r"^\+?[0-9\s\-()]{7,20}$")


def validate_client(data):
    """Общая валидация для добавления и редактирования клиента."""
    errors = {}

    name = (data.get("name") or "").strip()
    phone = (data.get("phone") or "").strip()
    email = (data.get("email") or "").strip().lower()
    balance_raw = (data.get("bonus_balance") or "").strip()
    date_raw = (data.get("registration_date") or "").strip()

    if not name:
        errors["name"] = "Введите имя."

    if not phone:
        errors["phone"] = "Введите телефон."
    elif not PHONE_RE.match(phone) or len(re.sub(r"\D", "", phone)) < 7:
        errors["phone"] = "Введите корректный телефон."

    if not email:
        errors["email"] = "Введите e-mail."
    elif not EMAIL_RE.match(email):
        errors["email"] = "Введите корректный e-mail."

    balance = None
    if not balance_raw:
        errors["bonus_balance"] = "Введите баланс бонусов."
    else:
        try:
            balance = Decimal(balance_raw.replace(",", "."))
            if balance < 0:
                errors["bonus_balance"] = "Баланс не может быть отрицательным."
        except InvalidOperation:
            errors["bonus_balance"] = "Баланс должен быть числом."

    if not date_raw:
        errors["registration_date"] = "Введите дату регистрации."
    else:
        try:
            datetime.strptime(date_raw, "%Y-%m-%d")
        except ValueError:
            errors["registration_date"] = "Введите дату в формате ГГГГ-ММ-ДД."

    cleaned = {
        "name": name,
        "phone": phone,
        "email": email,
        "bonus_balance": balance,
        "registration_date": date_raw,
    }
    return errors, cleaned
