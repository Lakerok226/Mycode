import os

DB_CONFIG = {
    "host": os.getenv("MYSQL_HOST", "localhost"),
    "user": os.getenv("MYSQL_USER", "root"),
    "password": os.getenv("MYSQL_PASSWORD", ""),
    "database": os.getenv("MYSQL_DATABASE", "cafe_clients"),
    "port": int(os.getenv("MYSQL_PORT", "3306")),
}

SECRET_KEY = os.getenv("SECRET_KEY", "change-me-in-production")
PER_PAGE = int(os.getenv("PER_PAGE", "5"))
