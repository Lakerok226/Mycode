import mysql.connector
from mysql.connector import IntegrityError

from config import DB_CONFIG


def get_connection():
    return mysql.connector.connect(**DB_CONFIG)


def _fetchone(sql, params=()):
    with get_connection() as conn:
        with conn.cursor(dictionary=True) as cur:
            cur.execute(sql, params)
            return cur.fetchone()


def _execute(sql, params=()):
    with get_connection() as conn:
        with conn.cursor() as cur:
            cur.execute(sql, params)
            conn.commit()
            return cur.lastrowid


def check_unique(phone, email, client_id=None):
    """Проверка уникальности телефона и e-mail. При редактировании текущий id исключается."""
    errors = {}

    sql = "SELECT id FROM clients WHERE phone = %s"
    params = [phone]
    if client_id:
        sql += " AND id <> %s"
        params.append(client_id)
    if phone and _fetchone(sql, params):
        errors["phone"] = "Клиент с таким телефоном уже существует."

    sql = "SELECT id FROM clients WHERE email = %s"
    params = [email]
    if client_id:
        sql += " AND id <> %s"
        params.append(client_id)
    if email and _fetchone(sql, params):
        errors["email"] = "Клиент с таким e-mail уже существует."

    return errors


def add_client(client):
    sql = """
        INSERT INTO clients (name, phone, email, bonus_balance, registration_date)
        VALUES (%s, %s, %s, %s, %s)
    """
    params = (
        client["name"],
        client["phone"],
        client["email"],
        client["bonus_balance"],
        client["registration_date"],
    )
    try:
        return _execute(sql, params)
    except IntegrityError:
        raise ValueError("Телефон или e-mail уже есть в базе.")


def update_client(client_id, client):
    sql = """
        UPDATE clients
        SET name = %s, phone = %s, email = %s, bonus_balance = %s, registration_date = %s
        WHERE id = %s
    """
    params = (
        client["name"],
        client["phone"],
        client["email"],
        client["bonus_balance"],
        client["registration_date"],
        client_id,
    )
    try:
        _execute(sql, params)
    except IntegrityError:
        raise ValueError("Телефон или e-mail уже есть в базе.")


def delete_client(client_id):
    _execute("DELETE FROM clients WHERE id = %s", (client_id,))


def get_client(client_id):
    return _fetchone("SELECT * FROM clients WHERE id = %s", (client_id,))


def list_clients(q="", min_balance=None, max_balance=None, page=1, per_page=5):
    where = []
    params = []

    if q:
        where.append("(name LIKE %s OR phone LIKE %s)")
        like = f"%{q}%"
        params.extend([like, like])

    if min_balance is not None:
        where.append("bonus_balance >= %s")
        params.append(min_balance)

    if max_balance is not None:
        where.append("bonus_balance <= %s")
        params.append(max_balance)

    where_sql = " WHERE " + " AND ".join(where) if where else ""

    count_sql = "SELECT COUNT(*) AS total FROM clients" + where_sql
    total_row = _fetchone(count_sql, params)
    total = total_row["total"] if total_row else 0

    offset = (page - 1) * per_page
    select_sql = """
        SELECT id, name, phone, email, bonus_balance, registration_date
        FROM clients
    """ + where_sql + " ORDER BY registration_date DESC, id DESC LIMIT %s OFFSET %s"

    with get_connection() as conn:
        with conn.cursor(dictionary=True) as cur:
            cur.execute(select_sql, params + [per_page, offset])
            clients = cur.fetchall()

    pages = max((total + per_page - 1) // per_page, 1)
    return clients, total, pages
