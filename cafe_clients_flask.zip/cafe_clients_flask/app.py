from decimal import Decimal, InvalidOperation

from flask import Flask, flash, redirect, render_template, request, url_for

import db
from config import PER_PAGE, SECRET_KEY
from validators import validate_client

app = Flask(__name__)
app.config["SECRET_KEY"] = SECRET_KEY


def parse_decimal_filter(value):
    value = (value or "").strip()
    if not value:
        return None
    try:
        number = Decimal(value.replace(",", "."))
        return number if number >= 0 else None
    except InvalidOperation:
        return None


@app.route("/")
def index():
    q = (request.args.get("q") or "").strip()
    min_balance = parse_decimal_filter(request.args.get("min_balance"))
    max_balance = parse_decimal_filter(request.args.get("max_balance"))

    try:
        page = max(int(request.args.get("page", 1)), 1)
    except ValueError:
        page = 1

    clients, total, pages = db.list_clients(q, min_balance, max_balance, page, PER_PAGE)
    if page > pages:
        page = pages
        clients, total, pages = db.list_clients(q, min_balance, max_balance, page, PER_PAGE)

    return render_template(
        "index.html",
        clients=clients,
        total=total,
        pages=pages,
        page=page,
        q=q,
        min_balance=request.args.get("min_balance", ""),
        max_balance=request.args.get("max_balance", ""),
        form={},
        errors={},
    )


@app.route("/add", methods=["POST"])
def add_client():
    errors, client = validate_client(request.form)

    # Уникальность проверяем только если формат телефона/e-mail уже нормальный.
    if not errors.get("phone") and not errors.get("email"):
        errors.update(db.check_unique(client["phone"], client["email"]))

    if errors:
        clients, total, pages = db.list_clients(per_page=PER_PAGE)
        return render_template(
            "index.html",
            clients=clients,
            total=total,
            pages=pages,
            page=1,
            q="",
            min_balance="",
            max_balance="",
            form=request.form,
            errors=errors,
        )

    try:
        db.add_client(client)
        flash("Клиент добавлен.", "green")
    except ValueError as exc:
        flash(str(exc), "red")
    return redirect(url_for("index"))


@app.route("/edit/<int:client_id>", methods=["GET", "POST"])
def edit_client(client_id):
    current = db.get_client(client_id)
    if not current:
        flash("Клиент не найден.", "red")
        return redirect(url_for("index"))

    if request.method == "POST":
        errors, client = validate_client(request.form)
        if not errors.get("phone") and not errors.get("email"):
            errors.update(db.check_unique(client["phone"], client["email"], client_id=client_id))

        if errors:
            return render_template("edit.html", client=current, form=request.form, errors=errors)

        try:
            db.update_client(client_id, client)
            flash("Данные клиента обновлены.", "green")
        except ValueError as exc:
            flash(str(exc), "red")
            return render_template("edit.html", client=current, form=request.form, errors=errors)
        return redirect(url_for("index"))

    return render_template("edit.html", client=current, form=current, errors={})


@app.route("/delete/<int:client_id>", methods=["POST"])
def delete_client(client_id):
    db.delete_client(client_id)
    flash("Клиент удалён.", "green")
    return redirect(url_for("index"))


if __name__ == "__main__":
    app.run(debug=True)
